﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextEditor
{
	public partial class FindReplaceForm : Form
	{
		int index_of = 0;
		TextBox main_form_tb;
		public FindReplaceForm()
		{
			InitializeComponent();
		}

		private void btnFindNext_Click(object sender, EventArgs e)
		{
			try
			{
				if (main_form_tb.TextLength > 0)
				{
					if (index_of + txbWhatFind.Text.Length > main_form_tb.TextLength)
					{
						MessageBox.Show("Информации не найдено", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
						index_of = 0;
						return;
					}
					int start = main_form_tb.Text.IndexOf(txbWhatFind.Text, index_of, (chkRegister.Checked) ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase);
					if (start == -1)
					{
						MessageBox.Show("Информации не найдено", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
						index_of = 0;
						return;
					}
					main_form_tb.SelectionStart = start;
					main_form_tb.SelectionLength = txbWhatFind.Text.Length;		
					index_of = start + txbWhatFind.Text.Length;

				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void FindReplaceForm_Load(object sender, EventArgs e)
		{
			main_form_tb = Tag as TextBox;
		}

		private void btnReplace_Click(object sender, EventArgs e)
		{
			try
			{
				if (main_form_tb.TextLength > 0)
				{
			
					if (main_form_tb.SelectedText.Length > 0)
					{
						if (chkRegister.Checked)
						{
							if (main_form_tb.SelectedText == txbWhatFind.Text)
							{
								main_form_tb.SelectedText = txbWichReplace.Text;
							}
						}
						else
						{
							if (main_form_tb.SelectedText.ToLower() == txbWhatFind.Text.ToLower())
							{
								main_form_tb.SelectedText = txbWichReplace.Text;
							}
						}
					}
					else
						MessageBox.Show("Текст для замены не выбран", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnReplaceAll_Click(object sender, EventArgs e)
		{
			try
			{
				if (chkRegister.Checked)
				{
					if (main_form_tb.Text.Contains(txbWhatFind.Text))
					{
						main_form_tb.Text = main_form_tb.Text.Replace(txbWhatFind.Text, txbWichReplace.Text);

					}
				}
				else
				{
					if (main_form_tb.Text.ToLower().Contains(txbWhatFind.Text.ToLower()))
					{
						main_form_tb.Text = main_form_tb.Text.Replace(txbWhatFind.Text.ToLower(), txbWichReplace.Text);

					}
				}
			}
			catch(Exception ee)
			{
				MessageBox.Show(ee.Message + ee.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			
			
		}

		private void btnExit_Click(object sender, EventArgs e)
		{
			main_form_tb.SelectionLength = 0;
	
			Close();
		}
	}
}
