﻿namespace TextEditor
{
	partial class FindReplaceForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnFindNext = new System.Windows.Forms.Button();
			this.btnReplace = new System.Windows.Forms.Button();
			this.btnReplaceAll = new System.Windows.Forms.Button();
			this.btnExit = new System.Windows.Forms.Button();
			this.chkRegister = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txbWhatFind = new System.Windows.Forms.TextBox();
			this.txbWichReplace = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnFindNext
			// 
			this.btnFindNext.Location = new System.Drawing.Point(296, 10);
			this.btnFindNext.Name = "btnFindNext";
			this.btnFindNext.Size = new System.Drawing.Size(102, 30);
			this.btnFindNext.TabIndex = 0;
			this.btnFindNext.Text = "Найти далее";
			this.btnFindNext.UseVisualStyleBackColor = true;
			this.btnFindNext.Click += new System.EventHandler(this.btnFindNext_Click);
			// 
			// btnReplace
			// 
			this.btnReplace.Location = new System.Drawing.Point(296, 46);
			this.btnReplace.Name = "btnReplace";
			this.btnReplace.Size = new System.Drawing.Size(102, 30);
			this.btnReplace.TabIndex = 1;
			this.btnReplace.Text = "Заменить";
			this.btnReplace.UseVisualStyleBackColor = true;
			this.btnReplace.Click += new System.EventHandler(this.btnReplace_Click);
			// 
			// btnReplaceAll
			// 
			this.btnReplaceAll.Location = new System.Drawing.Point(296, 82);
			this.btnReplaceAll.Name = "btnReplaceAll";
			this.btnReplaceAll.Size = new System.Drawing.Size(102, 30);
			this.btnReplaceAll.TabIndex = 2;
			this.btnReplaceAll.Text = "Заменить все";
			this.btnReplaceAll.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnReplaceAll.UseVisualStyleBackColor = true;
			this.btnReplaceAll.Click += new System.EventHandler(this.btnReplaceAll_Click);
			// 
			// btnExit
			// 
			this.btnExit.Location = new System.Drawing.Point(296, 118);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(102, 30);
			this.btnExit.TabIndex = 3;
			this.btnExit.Text = "Отмена";
			this.btnExit.UseVisualStyleBackColor = true;
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// chkRegister
			// 
			this.chkRegister.AutoSize = true;
			this.chkRegister.Location = new System.Drawing.Point(101, 118);
			this.chkRegister.Name = "chkRegister";
			this.chkRegister.Size = new System.Drawing.Size(115, 25);
			this.chkRegister.TabIndex = 4;
			this.chkRegister.Text = "Учет регистра";
			this.chkRegister.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(11, 15);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(32, 21);
			this.label1.TabIndex = 5;
			this.label1.Text = "Что";
			// 
			// txbWhatFind
			// 
			this.txbWhatFind.Location = new System.Drawing.Point(49, 12);
			this.txbWhatFind.Name = "txbWhatFind";
			this.txbWhatFind.Size = new System.Drawing.Size(231, 28);
			this.txbWhatFind.TabIndex = 6;
			// 
			// txbWichReplace
			// 
			this.txbWichReplace.Location = new System.Drawing.Point(49, 65);
			this.txbWichReplace.Name = "txbWichReplace";
			this.txbWichReplace.Size = new System.Drawing.Size(231, 28);
			this.txbWichReplace.TabIndex = 8;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(8, 71);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(35, 21);
			this.label2.TabIndex = 7;
			this.label2.Text = "Чем";
			// 
			// FindReplaceForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 21F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(414, 162);
			this.Controls.Add(this.txbWichReplace);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txbWhatFind);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.chkRegister);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.btnReplaceAll);
			this.Controls.Add(this.btnReplace);
			this.Controls.Add(this.btnFindNext);
			this.Font = new System.Drawing.Font("Minion Pro Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.MaximizeBox = false;
			this.Name = "FindReplaceForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "FindReplace";
			this.Load += new System.EventHandler(this.FindReplaceForm_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnFindNext;
		private System.Windows.Forms.Button btnReplace;
		private System.Windows.Forms.Button btnReplaceAll;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.CheckBox chkRegister;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txbWhatFind;
		private System.Windows.Forms.TextBox txbWichReplace;
		private System.Windows.Forms.Label label2;
	}
}