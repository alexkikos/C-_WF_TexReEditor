﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextEditor
{
	public partial class FindForm : Form
	{
		int where_to_go = 0;
		int register = 0;
		int start = 0;
		int of_index = 0;
		TextBox main_form_text_box;
		public int Where_to_go { get => where_to_go; }
		public int Register { get => register; }

		public FindForm(MainForm main)
		{
			InitializeComponent();
	
	
		}
		public FindForm()
		{
			InitializeComponent();
		}
		private void btnExit_Click(object sender, EventArgs e)
		{
			main_form_text_box.SelectionLength = 0;
			Close();
		}

		private void RdpUp_CheckedChanged(object sender, EventArgs e)
		{
			where_to_go = 1;
		}

		private void rdbDown_CheckedChanged(object sender, EventArgs e)
		{
			where_to_go = 0;
		}

		private void chcRegister_CheckedChanged(object sender, EventArgs e)
		{
			if (chcRegister.Checked)
			{
				register = 1;
			}
			else
				register = 0;
		}





		private void btnNext_Click(object sender, EventArgs e)
		{
			try
			{
				if (textBox1.TextLength > 0)
				{
					if (of_index < 0) of_index = 0;
					switch (where_to_go)
					{
						case 0:
							if (of_index >= main_form_text_box.Text.Length)
							{
								MessageBox.Show("Не удалось найти: " + textBox1.Text, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
								return;
							}
							//start = main_form.textBox1.Text.IndexOf(textBox1.Text, of_index, (chcRegister.Checked) ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase);
							start = (Tag as TextBox).Text.IndexOf(textBox1.Text, of_index, (chcRegister.Checked) ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase);

							if (start == -1)
							{
								return;
							}
							else	of_index = start + textBox1.Text.Length;
							break;
						case 1:
							if (of_index < 0)
							{
								MessageBox.Show("Не удалось найти: " + textBox1.Text, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
								return;
							}
							start = main_form_text_box.Text.LastIndexOf(textBox1.Text, of_index, (chcRegister.Checked) ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase);
							if (start == -1)
							{
								MessageBox.Show("Не удалось найти: " + textBox1.Text, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
								return;
							}
							else						
								of_index = start - textBox1.Text.Length;
							break;

					}
					if (start == -1) return;
					main_form_text_box.SelectionStart = start;
					main_form_text_box.SelectionLength = textBox1.Text.Length;				

				}
				else MessageBox.Show("No search params", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void FindForm_Load(object sender, EventArgs e)
		{
			main_form_text_box = Tag as TextBox;
		}
	}
}
