﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Runtime.Serialization.Formatters.Binary;






namespace TextEditor
{
	public partial class MainForm : Form
	{
		FindForm findForm;
		bool changed = false;
		bool ctrl = false;
		string path_file;
		string buffer_text;
		Regex regex;
		FileStream fileStream;
		public MainForm()
		{
			InitializeComponent();

			regex = new Regex(@"\w+\s", RegexOptions.Compiled);
			textBox1.MouseWheel += TextBox1_MouseWheel;
			path_file = "";

		}

		private void TextBox1_MouseWheel(object sender, MouseEventArgs e)
		{
			if (textBox1.Font.Size >= 8 && textBox1.Font.Size <= 24)
			{
				if (ctrl)
				{
					Font font;
					if (e.Delta > 0)
					{
						if (textBox1.Font.Size < 24)
						{
							font = new Font(textBox1.Font.FontFamily, textBox1.Font.Size + 1);
							textBox1.Font = font;
						}
					}
					else
					{
						if (textBox1.Font.Size > 8)
						{
							font = new Font(textBox1.Font.FontFamily, textBox1.Font.Size - 1);
							textBox1.Font = font;
						}
					}

					trackBar1.Value = (int)textBox1.Font.Size;
				}
			}
		}

		private void выходToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			try
			{


				if (MessageBox.Show("Confirm exit", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes)
				{
					e.Cancel = true;
				}
				else
				{
					if (!Directory.Exists(Environment.CurrentDirectory + @"\Settings\"))
					{
						Directory.CreateDirectory(Environment.CurrentDirectory + @"\Settings\");
					}
					if (Directory.Exists(Environment.CurrentDirectory + @"\Settings\"))
					{
						fileStream = new FileStream(Environment.CurrentDirectory + @"\Settings\User.bin", FileMode.Create, FileAccess.Write);
						BinaryFormatter binaryFormatter = new BinaryFormatter();
						binaryFormatter.Serialize(fileStream, MenuLoadStart.CheckState);
						binaryFormatter.Serialize(fileStream, this.Font);
						binaryFormatter.Serialize(fileStream, menuStrip1.Font);
						binaryFormatter.Serialize(fileStream, statusStrip1.Font);
						binaryFormatter.Serialize(fileStream, this.BackColor);
						binaryFormatter.Serialize(fileStream, menuStrip1.BackColor);
						binaryFormatter.Serialize(fileStream, statusStrip1.BackColor);
						binaryFormatter.Serialize(fileStream, textBox1.BackColor);
						binaryFormatter.Serialize(fileStream, textBox1.Font);
						binaryFormatter.Serialize(fileStream, trackBar1.BackColor);
						fileStream.Close();
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
				if (fileStream != null) fileStream.Close();
			}

		}

		private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				var res = openFileDialog.ShowDialog();
				if (res == DialogResult.OK)
				{
					fileStream = new FileStream(openFileDialog.FileName, FileMode.Open, FileAccess.Read);
					path_file = openFileDialog.FileName;
					StreamReader streamReader = new StreamReader(fileStream, Encoding.Default);
					var encod = streamReader.CurrentEncoding;

					toolStripStatusLabel3.Text = "Кодировка: " + encod.EncodingName;
					string s = streamReader.ReadToEnd();
					fileStream.Close();
					textBox1.Text = s;
					changed = false;
					сохранитьToolStripMenuItem.Enabled = false;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
				if (fileStream != null) fileStream.Close();
			}
		}



		private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (changed)
				{
					if (path_file.Length == 0)
					{
						SaveFileDialog saveFileDialog = new SaveFileDialog();
						if (saveFileDialog.ShowDialog() == DialogResult.OK)
						{
							path_file = saveFileDialog.FileName;
							fileStream = new FileStream(saveFileDialog.FileName, FileMode.Create, FileAccess.Write);
							StreamWriter streamWriter = new StreamWriter(fileStream);
							streamWriter.Write(textBox1.Text);
							streamWriter.Flush();
							fileStream.Close();
							changed = false;
							сохранитьToolStripMenuItem.Enabled = false;
						}
					}
					else
					{
						fileStream = new FileStream(path_file, FileMode.Create, FileAccess.Write);
						StreamWriter streamWriter = new StreamWriter(fileStream);
						streamWriter.Write(textBox1.Text);
						streamWriter.Flush();
						fileStream.Close();
						changed = false;
						сохранитьToolStripMenuItem.Enabled = false;
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
				if (fileStream != null) fileStream.Close();
			}
		}

		private void сохранитьКакToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				SaveFileDialog saveFileDialog = new SaveFileDialog();
				saveFileDialog.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*|Xml files(*.xml)|*.xml";

				if (saveFileDialog.ShowDialog() == DialogResult.OK)
				{
					fileStream = new FileStream(saveFileDialog.FileName, FileMode.Create, FileAccess.Write);
					StreamWriter streamWriter = new StreamWriter(fileStream);
					streamWriter.Write(textBox1.Text);
					streamWriter.Flush();
					fileStream.Close();
					MessageBox.Show("Выполнено", "Saving", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
				if (fileStream != null) fileStream.Close();
			}
		}

		private void найтиToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (textBox1.TextLength > 0)
			{
				findForm = new FindForm();
				findForm.Tag = textBox1;
				findForm.Show();

			}
			else MessageBox.Show("Нет текста для анализа!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
		}

		private void заменитьToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (textBox1.TextLength > 0)
			{
				FindReplaceForm findReplaceForm = new FindReplaceForm();
				findReplaceForm.Tag = textBox1;
				findReplaceForm.Show();
			}
			else MessageBox.Show("Нет текста для анализа!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			if (!toolStripStatusLabel1.Visible)
			{
				toolStripStatusLabel1.Visible = true;
				toolStripStatusLabel2.Visible = true;
				toolStripStatusLabel3.Visible = true;
				toolStripStatusLabel4.Visible = true;
				trackBar1.Visible = true;
			}
			if (!changed)
			{
				changed = true;
				сохранитьToolStripMenuItem.Enabled = true;
			}
			toolStripStatusLabel1.Text = "Символы: " + textBox1.TextLength.ToString();
			toolStripStatusLabel2.Text = "Строки: " + textBox1.Lines.Length.ToString();
			if (toolStripStatusLabel3.Text.Length < 1)
			{
				toolStripStatusLabel3.Text = "Кодировка: UTF-8";
			}
			MatchCollection matchCollection;
			matchCollection = regex.Matches(textBox1.Text);
			toolStripStatusLabel4.Text = "Количество слов: " + matchCollection.Count.ToString();
			toolStripStatusLabel5.Text = "Размер шрифта: " + textBox1.Font.Size.ToString();
		}


		private void нижняяПанельToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (colorDialog1.ShowDialog() == DialogResult.OK)
			{
				statusStrip1.BackColor = colorDialog1.Color;
				trackBar1.BackColor = colorDialog1.Color;
			}
		}

		private void главныйФреймToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (colorDialog1.ShowDialog() == DialogResult.OK)
			{
				this.BackColor = colorDialog1.Color;
			}
		}

		private void менюToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (colorDialog1.ShowDialog() == DialogResult.OK)
			{
				menuStrip1.BackColor = colorDialog1.Color;
			}
		}

		private void менбToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (fontDialog1.ShowDialog() == DialogResult.OK)
			{
				menuStrip1.Font = fontDialog1.Font;
			}
		}

		private void нижняяПанельToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			if (fontDialog1.ShowDialog() == DialogResult.OK)
			{
				statusStrip1.Font = fontDialog1.Font;
			}
		}

		private void главныйФреймToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			if (fontDialog1.ShowDialog() == DialogResult.OK)
			{
				this.Font = fontDialog1.Font;
			}
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			try
			{
				if (!Directory.Exists(Environment.CurrentDirectory + @"\Settings\"))
				{
					Directory.CreateDirectory(Environment.CurrentDirectory + @"\Settings\");
				}
				if (!File.Exists(Environment.CurrentDirectory + @"\Settings\default.bin"))
				{
					fileStream = new FileStream(Environment.CurrentDirectory + @"\Settings\default.bin", FileMode.Create, FileAccess.Write);
					BinaryFormatter binaryFormatter = new BinaryFormatter();
					binaryFormatter.Serialize(fileStream, MenuLoadStart.CheckState);
					binaryFormatter.Serialize(fileStream, this.Font);
					binaryFormatter.Serialize(fileStream, menuStrip1.Font);
					binaryFormatter.Serialize(fileStream, statusStrip1.Font);
					binaryFormatter.Serialize(fileStream, this.BackColor);
					binaryFormatter.Serialize(fileStream, menuStrip1.BackColor);
					binaryFormatter.Serialize(fileStream, statusStrip1.BackColor);
					binaryFormatter.Serialize(fileStream, textBox1.BackColor);
					binaryFormatter.Serialize(fileStream, textBox1.Font);
					binaryFormatter.Serialize(fileStream, trackBar1.BackColor);
					fileStream.Close();
				}
				if (File.Exists(Environment.CurrentDirectory + @"\Settings\User.bin"))
				{
					fileStream = new FileStream(Environment.CurrentDirectory + @"\Settings\User.bin", FileMode.Open, FileAccess.Read);
					BinaryFormatter binaryFormatter = new BinaryFormatter();
					MenuLoadStart.CheckState = (CheckState)binaryFormatter.Deserialize(fileStream);
					if (MenuLoadStart.Checked)
					{
						this.Font = (Font)binaryFormatter.Deserialize(fileStream);
						menuStrip1.Font = (Font)binaryFormatter.Deserialize(fileStream);
						statusStrip1.Font = (Font)binaryFormatter.Deserialize(fileStream);
						this.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
						menuStrip1.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
						statusStrip1.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
						textBox1.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
						textBox1.Font = (Font)binaryFormatter.Deserialize(fileStream);
						trackBar1.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
					}
					fileStream.Close();
				}
				trackBar1.Value = (int)textBox1.Font.Size;

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
				if (fileStream != null) fileStream.Close();
			}
		}

		private void MenuLoadStart_Click(object sender, EventArgs e)
		{
			if (MenuLoadStart.Checked) MenuLoadStart.Checked = false;
			else
			{
				MenuLoadStart.Checked = true;
			}
		}

		private void сбросНастроекToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (File.Exists(Environment.CurrentDirectory + @"\Settings\default.bin"))
				{
					fileStream = new FileStream(Environment.CurrentDirectory + @"\Settings\default.bin", FileMode.Open, FileAccess.Read);
					BinaryFormatter binaryFormatter = new BinaryFormatter();
					MenuLoadStart.CheckState = (CheckState)binaryFormatter.Deserialize(fileStream);
					this.Font = (Font)binaryFormatter.Deserialize(fileStream);
					menuStrip1.Font = (Font)binaryFormatter.Deserialize(fileStream);
					statusStrip1.Font = (Font)binaryFormatter.Deserialize(fileStream);
					this.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
					menuStrip1.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
					statusStrip1.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
					textBox1.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
					textBox1.Font = (Font)binaryFormatter.Deserialize(fileStream);
					trackBar1.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
					fileStream.Close();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
				if (fileStream != null) fileStream.Close();
			}
		}

		private void FonTMainTXB_Click(object sender, EventArgs e)
		{
			fontDialog1.ShowEffects = true;
			fontDialog1.ShowColor = true;
			if (fontDialog1.ShowDialog() == DialogResult.OK)
			{
				textBox1.Font = fontDialog1.Font;
			}
		}

		private void BackColorPalitra_Click(object sender, EventArgs e)
		{
			if (colorDialog1.ShowDialog() == DialogResult.OK)
			{
				textBox1.BackColor = colorDialog1.Color;
			}
		}

		private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
		{
			if (textBox1.SelectionLength > 0)
			{
				btnCopy.Enabled = true;
				btnCut.Enabled = true;
			}
			else
			{
				btnCopy.Enabled = false;
				btnCut.Enabled = false;
			}

			if (Clipboard.ContainsText())
			{
				BtnPast.Enabled = true;
			}

		}

		private void btnCopy_Click(object sender, EventArgs e)
		{
			if (textBox1.SelectedText != null)
			{
				buffer_text = textBox1.SelectedText;
			}
		}

		private void BtnPast_Click(object sender, EventArgs e)
		{
			textBox1.Paste();
			Clipboard.Clear();
			BtnPast.Enabled = false;
		}

		private void btnCut_Click(object sender, EventArgs e)
		{
			if (textBox1.SelectionLength > 0) textBox1.Cut();
		}

		private void textBox1_KeyDown(object sender, KeyEventArgs e)
		{
			if (textBox1.Font.Size <= 24 && textBox1.Font.Size >= 8)
			{
				if (e.KeyCode == Keys.Add && e.Modifiers == Keys.Control)
				{
					if (textBox1.Font.Size < 24)
					{
						Font font = new Font(textBox1.Font.FontFamily, textBox1.Font.Size + 1);
						textBox1.Font = font;
						trackBar1.Value = (int)textBox1.Font.Size;
					}
				}
				else
				if (e.KeyValue == 109 && e.Modifiers == Keys.Control)
				{
					if (textBox1.Font.Size > 8)
					{
						Font font = new Font(textBox1.Font.FontFamily, textBox1.Font.Size - 1);
						textBox1.Font = font;
						trackBar1.Value = (int)textBox1.Font.Size;
					}
				}
				if (e.Control) ctrl = true;
				toolStripStatusLabel5.Text = "Размер шрифта: " + textBox1.Font.Size.ToString();
			}

		}

		private void textBox1_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.ControlKey)
			{
				ctrl = false;
			}
		}

		private void RightFormat_Click(object sender, EventArgs e)
		{
			textBox1.TextAlign = HorizontalAlignment.Right;
		}

		private void центрToolStripMenuItem_Click(object sender, EventArgs e)
		{
			textBox1.TextAlign = HorizontalAlignment.Center;
		}

		private void левыйКрайToolStripMenuItem_Click(object sender, EventArgs e)
		{

			textBox1.TextAlign = HorizontalAlignment.Left;
		}



		private void печатьToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (printDialog1.ShowDialog() == DialogResult.OK)
			{
				printDialog1.Document = new System.Drawing.Printing.PrintDocument();
				printDialog1.Document.PrintPage += Document_PrintPage;
				printDialog1.Document.Print();
				printDialog1.Dispose();
			}

		}

		private void Document_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			e.Graphics.DrawString(textBox1.Text, textBox1.Font, Brushes.Black, 0, 0);
		}

		private void выйтиToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Close();
		}


		private void MainForm_SizeChanged(object sender, EventArgs e)
		{
			if (this.WindowState == FormWindowState.Minimized)
			{
				развернутьToolStripMenuItem.Enabled = true;
			}
			else
				if (this.WindowState == FormWindowState.Normal && развернутьToolStripMenuItem.Enabled)

			{
				развернутьToolStripMenuItem.Enabled = false;
			}
		}





		private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			if (this.WindowState == FormWindowState.Minimized)
			{
				this.WindowState = FormWindowState.Normal;
			}
		}

		private void развернутьToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.WindowState == FormWindowState.Minimized)
			{
				this.WindowState = FormWindowState.Normal;
			}
		}



		private void trackBar1_Scroll(object sender, EventArgs e)
		{
			textBox1.Font = new Font(textBox1.Font.FontFamily, trackBar1.Value);
			toolStripStatusLabel5.Text = "Размер шрифта: " + textBox1.Font.Size.ToString();
		}
	}
}
