﻿namespace TextEditor
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.btnCopy = new System.Windows.Forms.ToolStripMenuItem();
			this.btnCut = new System.Windows.Forms.ToolStripMenuItem();
			this.BtnPast = new System.Windows.Forms.ToolStripMenuItem();
			this.палитраToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.FonTMainTXB = new System.Windows.Forms.ToolStripMenuItem();
			this.BackColorPalitra = new System.Windows.Forms.ToolStripMenuItem();
			this.фомаритированиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.левыйКрайToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.центрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.RightFormat = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.сохранитьКакToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.печатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.правкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.найтиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.заменитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.шрифтToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.менбToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.нижняяПанельToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.главныйФреймToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.фонToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.менюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.нижняяПанельToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.главныйФреймToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.сбросНастроекToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.MenuLoadStart = new System.Windows.Forms.ToolStripMenuItem();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
			this.fontDialog1 = new System.Windows.Forms.FontDialog();
			this.colorDialog1 = new System.Windows.Forms.ColorDialog();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
			this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
			this.menuForNotify = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.развернутьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.выйтиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.printDialog1 = new System.Windows.Forms.PrintDialog();
			this.contextMenuStrip1.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			this.statusStrip1.SuspendLayout();
			this.menuForNotify.SuspendLayout();
			this.SuspendLayout();
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnCopy,
            this.btnCut,
            this.BtnPast,
            this.палитраToolStripMenuItem,
            this.фомаритированиеToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(178, 114);
			this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
			// 
			// btnCopy
			// 
			this.btnCopy.Enabled = false;
			this.btnCopy.Name = "btnCopy";
			this.btnCopy.Size = new System.Drawing.Size(177, 22);
			this.btnCopy.Text = "Копировать";
			this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
			// 
			// btnCut
			// 
			this.btnCut.Enabled = false;
			this.btnCut.Name = "btnCut";
			this.btnCut.Size = new System.Drawing.Size(177, 22);
			this.btnCut.Text = "Вырезать";
			this.btnCut.Click += new System.EventHandler(this.btnCut_Click);
			// 
			// BtnPast
			// 
			this.BtnPast.Enabled = false;
			this.BtnPast.Name = "BtnPast";
			this.BtnPast.Size = new System.Drawing.Size(177, 22);
			this.BtnPast.Text = "Вставить";
			this.BtnPast.Click += new System.EventHandler(this.BtnPast_Click);
			// 
			// палитраToolStripMenuItem
			// 
			this.палитраToolStripMenuItem.AutoToolTip = true;
			this.палитраToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FonTMainTXB,
            this.BackColorPalitra});
			this.палитраToolStripMenuItem.Name = "палитраToolStripMenuItem";
			this.палитраToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
			this.палитраToolStripMenuItem.Text = "Палитра";
			this.палитраToolStripMenuItem.ToolTipText = "Изменение Цвета текса и фона";
			// 
			// FonTMainTXB
			// 
			this.FonTMainTXB.Name = "FonTMainTXB";
			this.FonTMainTXB.Size = new System.Drawing.Size(113, 22);
			this.FonTMainTXB.Text = "Шрифт";
			this.FonTMainTXB.Click += new System.EventHandler(this.FonTMainTXB_Click);
			// 
			// BackColorPalitra
			// 
			this.BackColorPalitra.Name = "BackColorPalitra";
			this.BackColorPalitra.Size = new System.Drawing.Size(113, 22);
			this.BackColorPalitra.Text = "Фон";
			this.BackColorPalitra.Click += new System.EventHandler(this.BackColorPalitra_Click);
			// 
			// фомаритированиеToolStripMenuItem
			// 
			this.фомаритированиеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.левыйКрайToolStripMenuItem,
            this.центрToolStripMenuItem,
            this.RightFormat});
			this.фомаритированиеToolStripMenuItem.Name = "фомаритированиеToolStripMenuItem";
			this.фомаритированиеToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
			this.фомаритированиеToolStripMenuItem.Text = "Фомаритирование";
			this.фомаритированиеToolStripMenuItem.ToolTipText = "Выравнивание текста";
			// 
			// левыйКрайToolStripMenuItem
			// 
			this.левыйКрайToolStripMenuItem.Name = "левыйКрайToolStripMenuItem";
			this.левыйКрайToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
			this.левыйКрайToolStripMenuItem.Text = "Левый край";
			this.левыйКрайToolStripMenuItem.Click += new System.EventHandler(this.левыйКрайToolStripMenuItem_Click);
			// 
			// центрToolStripMenuItem
			// 
			this.центрToolStripMenuItem.Name = "центрToolStripMenuItem";
			this.центрToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
			this.центрToolStripMenuItem.Text = "Центр";
			this.центрToolStripMenuItem.Click += new System.EventHandler(this.центрToolStripMenuItem_Click);
			// 
			// RightFormat
			// 
			this.RightFormat.Name = "RightFormat";
			this.RightFormat.Size = new System.Drawing.Size(147, 22);
			this.RightFormat.Text = "Правый край";
			this.RightFormat.Click += new System.EventHandler(this.RightFormat_Click);
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.правкаToolStripMenuItem,
            this.настройкиToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Padding = new System.Windows.Forms.Padding(9, 3, 0, 3);
			this.menuStrip1.Size = new System.Drawing.Size(702, 25);
			this.menuStrip1.TabIndex = 1;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// файлToolStripMenuItem
			// 
			this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.сохранитьToolStripMenuItem,
            this.сохранитьКакToolStripMenuItem,
            this.toolStripSeparator1,
            this.печатьToolStripMenuItem,
            this.выходToolStripMenuItem});
			this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
			this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 19);
			this.файлToolStripMenuItem.Text = "Файл";
			// 
			// открытьToolStripMenuItem
			// 
			this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
			this.открытьToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.открытьToolStripMenuItem.Text = "Открыть";
			this.открытьToolStripMenuItem.Click += new System.EventHandler(this.открытьToolStripMenuItem_Click);
			// 
			// сохранитьToolStripMenuItem
			// 
			this.сохранитьToolStripMenuItem.Enabled = false;
			this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
			this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.сохранитьToolStripMenuItem.Text = "Сохранить";
			this.сохранитьToolStripMenuItem.ToolTipText = "Доступно при изменение в документе";
			this.сохранитьToolStripMenuItem.Click += new System.EventHandler(this.сохранитьToolStripMenuItem_Click);
			// 
			// сохранитьКакToolStripMenuItem
			// 
			this.сохранитьКакToolStripMenuItem.Name = "сохранитьКакToolStripMenuItem";
			this.сохранитьКакToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.сохранитьКакToolStripMenuItem.Text = "Сохранить как";
			this.сохранитьКакToolStripMenuItem.Click += new System.EventHandler(this.сохранитьКакToolStripMenuItem_Click);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
			// 
			// печатьToolStripMenuItem
			// 
			this.печатьToolStripMenuItem.Name = "печатьToolStripMenuItem";
			this.печатьToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.печатьToolStripMenuItem.Text = "Печать";
			this.печатьToolStripMenuItem.Click += new System.EventHandler(this.печатьToolStripMenuItem_Click);
			// 
			// выходToolStripMenuItem
			// 
			this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
			this.выходToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.выходToolStripMenuItem.Text = "Выход";
			this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
			// 
			// правкаToolStripMenuItem
			// 
			this.правкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.найтиToolStripMenuItem,
            this.заменитьToolStripMenuItem});
			this.правкаToolStripMenuItem.Name = "правкаToolStripMenuItem";
			this.правкаToolStripMenuItem.Size = new System.Drawing.Size(59, 19);
			this.правкаToolStripMenuItem.Text = "Правка";
			// 
			// найтиToolStripMenuItem
			// 
			this.найтиToolStripMenuItem.Name = "найтиToolStripMenuItem";
			this.найтиToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
			this.найтиToolStripMenuItem.Text = "Найти";
			this.найтиToolStripMenuItem.Click += new System.EventHandler(this.найтиToolStripMenuItem_Click);
			// 
			// заменитьToolStripMenuItem
			// 
			this.заменитьToolStripMenuItem.Name = "заменитьToolStripMenuItem";
			this.заменитьToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
			this.заменитьToolStripMenuItem.Text = "Заменить";
			this.заменитьToolStripMenuItem.Click += new System.EventHandler(this.заменитьToolStripMenuItem_Click);
			// 
			// настройкиToolStripMenuItem
			// 
			this.настройкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.шрифтToolStripMenuItem,
            this.фонToolStripMenuItem,
            this.сбросНастроекToolStripMenuItem,
            this.MenuLoadStart});
			this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
			this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(79, 19);
			this.настройкиToolStripMenuItem.Text = "Настройки";
			// 
			// шрифтToolStripMenuItem
			// 
			this.шрифтToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.менбToolStripMenuItem,
            this.нижняяПанельToolStripMenuItem1,
            this.главныйФреймToolStripMenuItem1});
			this.шрифтToolStripMenuItem.Name = "шрифтToolStripMenuItem";
			this.шрифтToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
			this.шрифтToolStripMenuItem.Text = "Шрифт";
			// 
			// менбToolStripMenuItem
			// 
			this.менбToolStripMenuItem.Name = "менбToolStripMenuItem";
			this.менбToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
			this.менбToolStripMenuItem.Text = "Меню";
			this.менбToolStripMenuItem.Click += new System.EventHandler(this.менбToolStripMenuItem_Click);
			// 
			// нижняяПанельToolStripMenuItem1
			// 
			this.нижняяПанельToolStripMenuItem1.Name = "нижняяПанельToolStripMenuItem1";
			this.нижняяПанельToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
			this.нижняяПанельToolStripMenuItem1.Text = "Нижняя панель";
			this.нижняяПанельToolStripMenuItem1.Click += new System.EventHandler(this.нижняяПанельToolStripMenuItem1_Click);
			// 
			// главныйФреймToolStripMenuItem1
			// 
			this.главныйФреймToolStripMenuItem1.Name = "главныйФреймToolStripMenuItem1";
			this.главныйФреймToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
			this.главныйФреймToolStripMenuItem1.Text = "Главный фрейм";
			this.главныйФреймToolStripMenuItem1.Click += new System.EventHandler(this.главныйФреймToolStripMenuItem1_Click);
			// 
			// фонToolStripMenuItem
			// 
			this.фонToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.менюToolStripMenuItem,
            this.нижняяПанельToolStripMenuItem,
            this.главныйФреймToolStripMenuItem});
			this.фонToolStripMenuItem.Name = "фонToolStripMenuItem";
			this.фонToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
			this.фонToolStripMenuItem.Text = "Фон";
			// 
			// менюToolStripMenuItem
			// 
			this.менюToolStripMenuItem.Name = "менюToolStripMenuItem";
			this.менюToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
			this.менюToolStripMenuItem.Text = "Меню";
			this.менюToolStripMenuItem.Click += new System.EventHandler(this.менюToolStripMenuItem_Click);
			// 
			// нижняяПанельToolStripMenuItem
			// 
			this.нижняяПанельToolStripMenuItem.Name = "нижняяПанельToolStripMenuItem";
			this.нижняяПанельToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
			this.нижняяПанельToolStripMenuItem.Text = "Нижняя панель";
			this.нижняяПанельToolStripMenuItem.Click += new System.EventHandler(this.нижняяПанельToolStripMenuItem_Click);
			// 
			// главныйФреймToolStripMenuItem
			// 
			this.главныйФреймToolStripMenuItem.Name = "главныйФреймToolStripMenuItem";
			this.главныйФреймToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
			this.главныйФреймToolStripMenuItem.Text = "Главный фрейм";
			this.главныйФреймToolStripMenuItem.Click += new System.EventHandler(this.главныйФреймToolStripMenuItem_Click);
			// 
			// сбросНастроекToolStripMenuItem
			// 
			this.сбросНастроекToolStripMenuItem.Name = "сбросНастроекToolStripMenuItem";
			this.сбросНастроекToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
			this.сбросНастроекToolStripMenuItem.Text = "Сброс настроек";
			this.сбросНастроекToolStripMenuItem.ToolTipText = "Возврат к изначальным настройках";
			this.сбросНастроекToolStripMenuItem.Click += new System.EventHandler(this.сбросНастроекToolStripMenuItem_Click);
			// 
			// MenuLoadStart
			// 
			this.MenuLoadStart.Checked = true;
			this.MenuLoadStart.CheckState = System.Windows.Forms.CheckState.Checked;
			this.MenuLoadStart.Name = "MenuLoadStart";
			this.MenuLoadStart.Size = new System.Drawing.Size(193, 22);
			this.MenuLoadStart.Text = "Загружать при старте";
			this.MenuLoadStart.ToolTipText = "Пользовательские настройки";
			this.MenuLoadStart.Click += new System.EventHandler(this.MenuLoadStart_Click);
			// 
			// statusStrip1
			// 
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel4,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel5});
			this.statusStrip1.Location = new System.Drawing.Point(0, 419);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(702, 22);
			this.statusStrip1.TabIndex = 2;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// toolStripStatusLabel1
			// 
			this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
			this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Visible = false;
			// 
			// toolStripStatusLabel4
			// 
			this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
			this.toolStripStatusLabel4.Size = new System.Drawing.Size(101, 17);
			this.toolStripStatusLabel4.Text = "Количество слов";
			this.toolStripStatusLabel4.Visible = false;
			// 
			// toolStripStatusLabel2
			// 
			this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
			this.toolStripStatusLabel2.Size = new System.Drawing.Size(118, 17);
			this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
			this.toolStripStatusLabel2.Visible = false;
			// 
			// toolStripStatusLabel3
			// 
			this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
			this.toolStripStatusLabel3.Size = new System.Drawing.Size(0, 17);
			this.toolStripStatusLabel3.Visible = false;
			// 
			// toolStripStatusLabel5
			// 
			this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
			this.toolStripStatusLabel5.Size = new System.Drawing.Size(0, 17);
			// 
			// textBox1
			// 
			this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.textBox1.ContextMenuStrip = this.contextMenuStrip1;
			this.textBox1.HideSelection = false;
			this.textBox1.Location = new System.Drawing.Point(14, 38);
			this.textBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.textBox1.Size = new System.Drawing.Size(676, 366);
			this.textBox1.TabIndex = 0;
			this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
			this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
			this.textBox1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyUp);
			// 
			// notifyIcon1
			// 
			this.notifyIcon1.ContextMenuStrip = this.menuForNotify;
			this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
			this.notifyIcon1.Text = "TextEditor";
			this.notifyIcon1.Visible = true;
			this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
			// 
			// menuForNotify
			// 
			this.menuForNotify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.развернутьToolStripMenuItem,
            this.выйтиToolStripMenuItem});
			this.menuForNotify.Name = "menuForNotify";
			this.menuForNotify.Size = new System.Drawing.Size(136, 48);
			// 
			// развернутьToolStripMenuItem
			// 
			this.развернутьToolStripMenuItem.Enabled = false;
			this.развернутьToolStripMenuItem.Name = "развернутьToolStripMenuItem";
			this.развернутьToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
			this.развернутьToolStripMenuItem.Text = "Развернуть";
			this.развернутьToolStripMenuItem.ToolTipText = "Активно, когда окно свернуто";
			this.развернутьToolStripMenuItem.Click += new System.EventHandler(this.развернутьToolStripMenuItem_Click);
			// 
			// выйтиToolStripMenuItem
			// 
			this.выйтиToolStripMenuItem.Name = "выйтиToolStripMenuItem";
			this.выйтиToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
			this.выйтиToolStripMenuItem.Text = "Выйти";
			this.выйтиToolStripMenuItem.Click += new System.EventHandler(this.выйтиToolStripMenuItem_Click);
			// 
			// printDialog1
			// 
			this.printDialog1.AllowCurrentPage = true;
			this.printDialog1.UseEXDialog = true;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(702, 441);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.menuStrip1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MainMenuStrip = this.menuStrip1;
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "TextEditor";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.SizeChanged += new System.EventHandler(this.MainForm_SizeChanged);
			this.contextMenuStrip1.ResumeLayout(false);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.menuForNotify.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem сохранитьКакToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem правкаToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem найтиToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem заменитьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem настройкиToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem шрифтToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem фонToolStripMenuItem;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
		private System.Windows.Forms.FontDialog fontDialog1;
		private System.Windows.Forms.ColorDialog colorDialog1;
		private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem нижняяПанельToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem главныйФреймToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem менбToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem нижняяПанельToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem главныйФреймToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem сбросНастроекToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem MenuLoadStart;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem btnCopy;
		private System.Windows.Forms.ToolStripMenuItem btnCut;
		private System.Windows.Forms.ToolStripMenuItem BtnPast;
		private System.Windows.Forms.ToolStripMenuItem палитраToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem FonTMainTXB;
		private System.Windows.Forms.ToolStripMenuItem BackColorPalitra;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.ToolStripMenuItem фомаритированиеToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem левыйКрайToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem центрToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem RightFormat;
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
		private System.Windows.Forms.NotifyIcon notifyIcon1;
		private System.Windows.Forms.ToolStripMenuItem печатьToolStripMenuItem;
		private System.Windows.Forms.PrintDialog printDialog1;
		private System.Windows.Forms.ContextMenuStrip menuForNotify;
		private System.Windows.Forms.ToolStripMenuItem развернутьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem выйтиToolStripMenuItem;
	}
}

